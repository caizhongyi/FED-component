module.exports = require('./lib/transparency');
