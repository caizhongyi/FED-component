$(function(){

	// Kick things off by creating the **App**.
	var App = new window.app.AppView;

});