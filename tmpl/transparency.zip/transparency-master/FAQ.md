# Frequently Asked Questions

Please refer to [on-line FAQ at Github wiki](https://github.com/leonidas/transparency/wiki/Frequently-Asked-Questions)