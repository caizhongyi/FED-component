(function(){if(!
/*@cc_on!@*/
0){return}var e="abbr,article,aside,audio,bb,canvas,datagrid,datalist,details,dialog,eventsource,figure,footer,hgroup,header,mark,menu,meter,nav,output,progress,section,time,video".split(","),i=0,length=e.length;while(i<length){document.createElement(e[i++])}})();