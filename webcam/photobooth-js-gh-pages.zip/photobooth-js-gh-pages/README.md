photobooth-js
=============

A html5 widget that allows users to take their avatar pictures on your site.

For demos and documentation please see [http://wolframhempel.github.com/photobooth-js/](http://wolframhempel.github.com/photobooth-js/)